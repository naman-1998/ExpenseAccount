import React from 'react'

const Liabilities = () => {
    return (
        <div>
            
        </div>
    )
}

export default Liabilities
