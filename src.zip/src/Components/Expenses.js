import React from 'react'

const Expenses = () => {
    return (
        <div>
            
        </div>
    )
}

export default Expenses
