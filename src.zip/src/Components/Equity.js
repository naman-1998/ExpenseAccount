import React from 'react'

const Equity = () => {
    return (
        <div>
            
        </div>
    )
}

export default Equity
